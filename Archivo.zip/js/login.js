document.addEventListener("DOMContentLoaded", function(e) {
    document.getElementById("login").addEventListener("click", function() {
        let email = document.getElementById("inputemail");
        let pass = document.getElementById("inputpass");
        

        if ((email.value === "") || (pass.value === "")) {
            alert("Hay Campos Vacios");

        } else {
            window.location = "inicio.html";
        }

    });



});